<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arTemplate = Array(
	"NAME"=>GetMessage("CSST_TEMPLATE_NAME"), 
	"EDITOR_STYLES" => array (
		'/bitrix/css/main/bootstrap.css',
		'/bitrix/css/main/font-awesome.css',
	)
);?>