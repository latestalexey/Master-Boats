<?
$MESS["CP_BCC_TPL_THEME_SITE"] = "Брать тему из настроек сайта (для решения bitrix.eshop)";
$MESS["CP_BCC_TPL_THEME_BLUE"] = "синяя (тема по умолчанию)";
$MESS["CP_BCC_TPL_THEME_GREEN"] = "зеленая";
$MESS["CP_BCC_TPL_THEME_RED"] = "красная";
$MESS["CP_BCC_TPL_THEME_WOOD"] = "дерево";
$MESS["CP_BCC_TPL_THEME_YELLOW"] = "желтая";
$MESS["CP_BCC_TPL_THEME_BLACK"] = "темная";
$MESS["CP_BCC_TPL_TEMPLATE_THEME"] = "Цветовая тема";
?>