<?
$MESS["CP_BCT_TPL_ROTATE_TIMER"] = "Advance slide after, sec. (0 - don't change slides)";
$MESS["ROTATE_TIMER_TIP"] = "Specifies the time a slide appears on the screen. This parameter in used when auto advancing slides.";
?>