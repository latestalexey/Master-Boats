<?
$MESS ['MENU_DOT_DEFAULT_NAME'] = "Default vertical menu";
$MESS ['MENU_DOT_DEFAULT_DESC'] = "Default vertical menu";
?>