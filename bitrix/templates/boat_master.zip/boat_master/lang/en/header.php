<?
$MESS["SEARCH_GOODS"] = "Products";
$MESS["SEARCH_OTHER"] = "Other";
$MESS["FOOTER_COMPANY_ABOUT"] = "About Us";
$MESS["FOOTER_COMPANY_PHONE"] = "Contact Us";
?>